## Assessment Video Solutions

password: **go_bootcamp_go**

### Assessment 7
+ [numberPrimes](https://vimeo.com/212646721)
+ [longestBigram](https://vimeo.com/212646692)
+ [longestLetterStreak](https://vimeo.com/212646651)
+ [previousPrimeArray](https://vimeo.com/212646629)
