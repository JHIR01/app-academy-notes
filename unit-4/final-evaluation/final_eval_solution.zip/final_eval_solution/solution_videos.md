## Assessment Video Solutions

password: **go_bootcamp_go**

### Final Evaluation
- [wordSandwich](https://vimeo.com/248528908/282be970ce)
- [reverseString](https://vimeo.com/248528876/0f86c74e8c)
- [negativeSum](https://vimeo.com/248528873/8a549dc05d)
- [usernames](https://vimeo.com/248528900/314870296c)
- [isPowerOfTwo](https://vimeo.com/250503676/a5b30aaa48)
- [areCoprime](https://vimeo.com/248528843/15e787cf4d)
- [shoppingCartCost](https://vimeo.com/248528886/499dc75e57)
- [pyramidScheme](https://vimeo.com/248528857/e51d7249f6)
