## Assessment Video Solutions

password: **go_bootcamp_go**

### Assessment 6
+ [myMap](https://vimeo.com/212515670)
+ [isPalindrome](https://vimeo.com/212515655)
+ [passingStudents](https://vimeo.com/212515640)
+ [laligatArray](https://vimeo.com/213127281)
+ [disemvowel](https://vimeo.com/212515590)
