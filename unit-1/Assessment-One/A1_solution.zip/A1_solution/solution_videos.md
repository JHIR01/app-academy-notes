## Assessment Video Solutions

password: **go_bootcamp_go**

### Assessment 1
+ [range](https://vimeo.com/212516068)
+ [reverseSentence](https://vimeo.com/212516050)
+ [unique](https://vimeo.com/212516029)
+ [fizzBuzz](https://vimeo.com/212516003)
+ [stringRange](https://vimeo.com/212515985)
