## Assessment Video Solutions

password: **go_bootcamp_go**

### Assessment 2
+ [reverseRange](https://vimeo.com/212515979)
+ [isPrime](https://vimeo.com/212515970)
+ [magicNumber](https://vimeo.com/212515961)
+ [firstAndLast](https://vimeo.com/212515949)
+ [royalWe](https://vimeo.com/212515920)
