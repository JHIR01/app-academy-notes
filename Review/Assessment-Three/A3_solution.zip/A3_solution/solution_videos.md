## Assessment Video Solutions

password: **go_bootcamp_go**

### Assessment 3
+ [myIndexOf](https://vimeo.com/212515904)
+ [minMaxDifference](https://vimeo.com/212515890)
+ [divisibleBy](https://vimeo.com/212515874)
+ [dynamicFizzBuzz](https://vimeo.com/212515861)
+ [magicCipher](https://vimeo.com/212515847)
reviousPrimeArray](https://vimeo.com/212646629)
