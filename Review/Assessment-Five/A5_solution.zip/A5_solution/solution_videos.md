## Assessment Video Solutions

password: **go_bootcamp_go**

### Assessment 5
+ [highestScore](https://vimeo.com/212515746)
+ [snakeToCamel](https://vimeo.com/212515728)
+ [sum2DArray](https://vimeo.com/212515710)
+ [minValueCallback](https://vimeo.com/212515696)
+ [mySelect](https://vimeo.com/212515682)
