## Assessment Video Solutions

password: **go_bootcamp_go**

### Assessment 4
+ [arrayBuilder](https://vimeo.com/212515826)
+ [longestWord](https://vimeo.com/212515816)
+ [leastCommonMultiple](https://vimeo.com/212515802)
+ [sillyCipher](https://vimeo.com/212515793)
+ [hipsterfy](https://vimeo.com/212515762)
